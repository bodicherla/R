setwd("C:\\Users\\sbodicherla164331\\OneDrive - Applied Materials\\Desktop\\Simplilearn\\1567503160_comcasttelecomcomplaintsdata")
cd=read.csv("Comcast Telecom Complaints data.csv")
View(cd)
sum(is.na(cd))#no null values
summary(cd)
str(cd)
#---------------changing into one single format--------------#
a <- as.Date(cd$Date,format="%d-%m-%Y") # Produces NA when format is not "%m/%d/%Y"
b <- as.Date(cd$Date,format="%d/%m/%Y") # Produces NA when format is not "%d.%m.%Y"
a[is.na(a)] <- b[!is.na(b)] # Combine both while keeping their ranks
cd$DateModified <- a # Put it back in your dataframe
View(cd)
class(cd$DateModified)
cd$Year=format(cd$DateModified,format="%Y")
cd$month=format(cd$DateModified,format="%m")
cd$day=format(cd$DateModified,format="%d")
View(cd)
cd$Year=as.factor(cd$Year)
str(cd$Year)#Confirms that there is only one year of data
cd$month=as.factor(cd$month)
str(cd$month)
#------------Aggregating number of complaints month wise and plotting a trend chart-----------------#

cd1=aggregate(cbind(count = cd$Ticket..) ~ month, 
          data = cd, 
          FUN = function(x){NROW(x)})
class(cd1)
cd1
names(cd1)
library(dplyr)
library(ggplot2)
cd1$month=as.numeric(cd1$month)
cd1$count=as.numeric(cd1$count)
ggplot(cd1,aes(x=month,y=count))+geom_line()+geom_point()+
  scale_x_continuous(breaks=seq(1,12,by=1))+labs(title="Trend Chart of number of complaints monthly level")+
  xlab("Month in number")+ylab("Number of Complaints")

#------------Aggregating number of complaints daily wise and plotting a trend chart-----------------#

cd2=cd %>%
  group_by(DateModified)  %>% summarise(count=n())
cd2
cd2$DateModified <- as.Date(cd2$DateModified,format="%d-%m-%Y")
class(cd2$DateModified)
ggplot(cd2,aes(x=DateModified,y=count))+geom_line()+geom_point()+
  labs(title="Trend Chart of number of complaints Daily")+
  xlab("Day")+ylab("Number of Complaints")+
  scale_x_date(date_breaks = "months" , date_labels = "%b-%y",limits = as.Date(c("2015-01-01","2015-12-31"))) 

#------------------Frequency table of complaint types---------------------------#
cd$Complaint_type=ifelse( grepl("*network*",cd$Customer.Complaint,ignore.case=T),"Network",
                          ifelse(grepl("*bill*|*refund*|*price*",cd$Customer.Complaint,ignore.case=T),"Billing",
                          ifelse(grepl("*internet*|*speed*|*cap*|*data*",cd$Customer.Complaint,ignore.case=T),"InternetIssues",
                          ifelse(grepl("*charge*",cd$Customer.Complaint,ignore.case=T),"Charge",
                          ifelse(grepl("*service*",cd$Customer.Complaint,ignore.case=T),"Service","others")))))
table(cd$Complaint_type)
View(table(cd$Complaint_type))#------------Internet Issues are more--------#
#--------------------Creating a new categorical variable with value as Open and Closed--------#
cd$Status=as.factor(cd$Status)
str(cd$Status)
cd$StatusModified=ifelse( grepl("Open|Pending",cd$Status,ignore.case=T),"Open",
                          ifelse(grepl("Closed|Solved",cd$Status,ignore.case=T),"Closed","others"))
cd$StatusModified
View(cd)
#-------------------Stacked barchart for number of complaints statewise-------------------------------#
cd$State[cd$State=="District of Columbia"]="District Of Columbia"
cd3=cd %>%
  group_by(State,StatusModified)  %>% summarise(TotalComplaints=n())
View(cd3)

ggplot(data = cd3, aes(x = State, y = TotalComplaints, fill = StatusModified)) + 
  geom_bar(stat='identity',width=0.6,color="black",size=0.5,alpha=0.7)+
  theme(legend.position="right",axis.text.x=element_text(angle=90,hjust=0.5))+
  labs(x="State",y="Number OF complaints",title="Stacked barchart for number of complaints statewise")
#---------Georgia has highest number of complaints---------#
#___________________________________________________________________#
#---------------------------------------------Percentage of unresolved Complaints----------------------#

cd3%>%
  filter(StatusModified == "Open")->
  open_complaints
View(open_complaints)
open_complaints$percentage=(open_complaints$TotalComplaints/sum(open_complaints$TotalComplaints))*100
View(open_complaints)
HighestPercentage=max(open_complaints$percentage)
HighestPercentage
open_complaints[open_complaints$percentage==HighestPercentage,]#--------------Georgia has highest complaints unresolved--------------#

#_____________the percentage of complaints resolved till date, which were received through the Internet and customer care calls.------#
str(cd$Received.Via)
cd$Received.Via=as.factor(cd$Received.Via)
str(cd$Received.Via)
cd4=cd %>%
  group_by(Received.Via,StatusModified)  %>% summarise(TotalComplaints=n())
View(cd4)
cd4%>%
  filter(StatusModified == "Closed")->
  closed_complaints
closed_complaints
closed_complaints$percentage=(closed_complaints$TotalComplaints/sum(cd4$TotalComplaints))*100
closed_complaints
