setwd("C:\\Users\\sbodicherla164331\\Desktop\\Simplilearn")
getwd()
data=read.csv("College_admission.csv")
View(data)
summary(data)
str(data)



#--------------missingValues--------------------#
is.na.data.frame(data)
sum(is.na.data.frame(data))#Sum is '0'.This ensures that there are no missing values

#--------------------outliers-------------------#

boxplot(data,main="Boxplot of entire dataframe")#Outliers are present in gre and gpa
boxplot(data$gre,main="Boxplot of gre before outliers treatment")
quantile(data$gre)
boxplot(data$gpa,main="Boxplot of gpa before outliers treatment")
quantile(data$gpa)
iqr_gre=IQR(data$gre)
iqr_gpa=IQR(data$gpa)

q1_gre=quantile(data$gre,0.25)
q1_gre  #first quantile
q3_gre=quantile(data$gre,0.75)
q3_gre #Third quantile

lw_gre=q1_gre-1.5*iqr_gre
lw_gre#lower whisker
uw_gre=q3_gre+1.5*iqr_gre
uw_gre#upper whisker

data$gre=replace(data$gre,data$gre<lw_gre,lw_gre)#removed the outliers in gre column
#No outliers present above upper whisker


q1_gpa=quantile(data$gpa,0.25)
q1_gpa  #first quantile
q3_gpa=quantile(data$gpa,0.75)
q3_gpa#Third quantile

lw_gpa=q1_gpa-1.5*iqr_gpa
lw_gpa #lower whisker
uw_gpa=q3_gre+1.5*iqr_gre
uw_gpa#upper whisker

data$gpa=replace(data$gpa,data$gpa<lw_gpa,lw_gpa)#removed the outliers in gpa column
#No outliers present above upper whisker


#COnfirming the outliers are removed
boxplot(data$gre,main="Boxplot of gre after outliers treatment")
boxplot(data$gpa,main="Boxplot of gpa after outliers treatment")



#-----------------------converting into factors and numeric---------#
str(data)
data$admit=as.factor(data$admit)#-----categrorical ,so converted to factor
data$ses=as.factor(data$ses)#-----categrorical ,so converted to factor
data$Race=as.factor(data$Race)#-----categrorical ,so converted to factor
data$Gender_Male=as.factor(data$Gender_Male)#-----categrorical ,so converted to factor
data$rank=as.factor(data$rank)#-----categrorical ,so converted to factor
data$gre=as.numeric(data$gre)
data$gpa=as.numeric(data$gpa)
str(data)
#-------------------to determine the normal distribution using R-------#
hist(data$gre)
hist(data$gpa)
dens_gre=dnorm(data$gre,mean(data$gre),sd(data$gre))
plot(data$gre,dens_gre,type="l")
dens_gpa=dnorm(data$gpa,mean(data$gpa),sd(data$gpa))
plot(data$gpa,dens_gpa,type="l")
str(data)
plot(density(data$gre),main="Density plot of gre before normalization")
plot(density(data$gpa),main="Density plot of gpa before normalization")

shapiro.test(data$gre)
shapiro.test(data$gpa)
normalize=function(x){
  return ((x-median(x))/IQR(x))
}
norm_data=as.data.frame(apply(data[2:3],2,normalize))
data$gre=norm_data$gre
data$gpa=norm_data$gpa

data$gre=scale(data$gre,center=TRUE,scale=TRUE)
data$gre
data$gpa=scale(data$gre,center=TRUE,scale=TRUE)
data$gpa
plot(density(data$gre),main="Density plot of gre after normalization")
plot(density(data$gpa),main="Density plot of gpa after normalization")


#-------------------variable reduction technique(stepAIC)-----------#
FitAll=glm(admit~.,data=data,family="binomial")
FitStart=glm(admit ~ 1 , data= data, family="binomial")
step1=step(FitStart,direction='both',scope=formula(FitAll))#found that the significant variables are rank+gpa+gre

#-------------------Splitting of data and building the model -------------------#

row_ind = sample(1:nrow(data), 0.7*nrow(data))
train_data = data[row_ind,]
test_data = data[-row_ind,]

glm(admit ~ rank +gre, data= train_data, family="binomial") ->log_mod1
options(scipen=999)
summary(log_mod1)
train_y=predict(log_mod1,train_data,type="response")
class(train_y)
train_y<-ifelse(train_y > mean(train_y, na.rm = T),1,0)
train_y=as.factor(train_y)
install.packages("e1071")
library(e1071)
library(caret)
confusionMatrix(train_data$admit,train_y,positive='1')#0.6464 -Accuracy, Sensitivity : 0.4622 ,Specificity : 0.7826 

svm(admit ~ rank +gre, data= train_data, family="binomial")->log_mod2
options(scipen=999)
summary(log_mod2)
train_y=predict(log_mod2,train_data,type="response")
train_y=as.numeric(train_y)
train_y<-ifelse(train_y > mean(train_y, na.rm = T),1,0)
train_y=as.factor(train_y)
class(train_y)
confusionMatrix(train_data$admit,train_y,positive='1')#0.7107 -Accuracy,Sensitivity : 0.60465 ,Specificity : 0.72996 

install.packages("rpart.plot")	
library(rpart.plot)

rpart(admit ~ rank +gre, data= train_data, method='class')->log_mod3
options(scipen=999)
summary(log_mod3)
train_y=predict(log_mod3,train_data,type="response")
train_y=as.numeric(train_y)
train_y<-ifelse(train_y > mean(train_y, na.rm = T),1,0)
train_y=as.factor(train_y)
class(train_y)
confusionMatrix(train_data$admit,train_y,positive='1')#0.7107-Accuracy,Sensitivity : 0.60465,Specificity : 0.72996 

-------#selecting svm or rpart as accuracy is high in both the model-----------#

svm(admit ~ rank +gre, data= test_data, family="binomial")->log_mod2_test
options(scipen=999)
summary(log_mod2_test)
test_y=predict(log_mod2_test,test_data,type="response")
test_y=as.numeric(test_y)
test_y<-ifelse(test_y > mean(test_y, na.rm = T),1,0)
test_y=as.factor(test_y)
class(test_y)
confusionMatrix(test_data$admit,test_y,positive='1')#Accuracy : 0.7167 , Sensitivity : 0.80000,Specificity : 0.71304  




