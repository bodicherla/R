setwd("C:\\Users\\sbodicherla164331\\OneDrive - Applied Materials\\Desktop\\Simplilearn")
library(readxl)
my_data=read_excel("1555054100_hospitalcosts.xlsx")
View(my_data)
sum(is.na(my_data))
my_data=na.omit(my_data)
sum(is.na(my_data))
#--------------------1. To record the patient statistics, the agency 
#wants to find the age category of people who frequently visit the hospital and has the maximum expenditure._____#
set.seed(42)
summary(my_data)
str(my_data)
my_data$AGE=as.factor(my_data$AGE)
str(my_data)
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}
Mode(my_data$AGE)#-------------The age '0' category frequently visir the hospital------#
my_data1=my_data%>%group_by(AGE)%>%summarise(TotalExpenditure=sum(TOTCHG))
View(my_data1)
max_exp=max(my_data1$TotalExpenditure)
my_data1[my_data1$TotalExpenditure==max_exp,]#-----Age '0'has the max.exp of 676962----#

#----------2. In order of severity of the diagnosis and treatments and to find out the expensive treatments, 
#the agency wants to find the diagnosis-related group that has maximum hospitalization and expenditure.----#
my_data2=my_data%>%group_by(APRDRG)%>%summarise(TotalExpenditure=sum(TOTCHG))
View(my_data2)
max_exp_p=max(my_data2$TotalExpenditure)
my_data2[my_data2$TotalExpenditure==max_exp_p,]#-------The group 640 has max exp of  436822----####
my_data3=my_data%>%group_by(APRDRG)%>%summarise(TotalLOS=sum(LOS))
View(my_data3)
max_LOS=max(my_data3$TotalLOS)
my_data3[my_data3$TotalLOS==max_LOS,]#-------The group 640 has max LOS of 650---####
#------------To make sure that there is no malpractice, the agency needs to analyze 
#if the race of the patient is related to the hospitalization costs.-----------#
str(my_data$RACE)
my_data$RACE=as.numeric(my_data$RACE)
my_data$TOTCHG=as.numeric(my_data$TOTCHG)
str(my_data$RACE)

cor.test(my_data$RACE, my_data$TOTCHG)#--------as p value is 0.6856(>0.05),
#the race of the patient is not related to the hospitalization costs.---#


#----To properly utilize the costs, the agency has to analyze the severity of the hospital costs by age 
#and gender for the proper allocation of resources.------------#
str(my_data$FEMALE)
my_data$FEMALE=as.factor(my_data$FEMALE)
influenceoncosts <- aov(TOTCHG ~AGE+FEMALE, data=my_data)
influenceoncosts
options(scipen=999)
summary(influenceoncosts)#------as pr value for AGE is less than 0.05,it is significant,where as for Gender as it is greater than 
#0.05 it is non-significant
model=lm(TOTCHG~AGE+FEMALE,data=my_data)
summary(model)

#Since the length of stay is the crucial factor for inpatients, 
#the agency wants to find if the length of stay can be predicted from age, gender, and race.
model1=lm(LOS~AGE+FEMALE+RACE,data=my_data)
summary(model1)#-----As p value is higher than 0.05,the variables are insignifacant to predict the LOS-------#

#To perform a complete analysis, the agency wants to find the variable that mainly affects hospital costs.
FitAll=lm(TOTCHG~.,data=my_data)
FitStart=lm(TOTCHG ~ 1 , data= my_data)
step1=step(FitStart,direction='both',scope=formula(FitAll))#found that the significant variables are APRDRG,AGE and LOS 



